﻿using System;

namespace IQWIA_WebApi.Models
{
    public class ClientRequest
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string TweetId { get; set; }
    }
}