﻿
namespace IQWIA_WebApi.Models
{
    public class MonthlyRequest
    {
        public string StartDate { get; set; }
        
        public string EndDate { get; set; }
    }
}