﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace IQWIA_WebApi.Models
{
    /// <summary>
    /// This class is used for calling the existing Swigger Api.
    /// </summary>
    public class TweetService
    {
        /// <summary>
        /// This method is used for calling the swigger api
        /// </summary>
        /// <param name="clientRequest">Client request. This request can contain tweetid whihc can be used for filter the data.</param>
        /// <returns>return list of tweets</returns>
        public async Task<List<TweetDetail>> GetTweetsAsync(ClientRequest clientRequest)
        {
            try
            {
                // API base URL
                string URL = Convert.ToString(WebConfigurationManager.AppSettings["ApiBaseUrl"]);

                HttpClient client = new HttpClient()
                {
                    BaseAddress = new Uri(URL)
                };

                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                // This function is used for split the start date and end date into list of months.
                // So on the basis of months processing the Asyns request.
                // Like 1 Jan-2016 to 31-Dec-2018 we craete 35 diff async calls and later merge all the data.
                // Split the data monthly it is configurable. we can change as per this parameter as per our reuirement.
                var monthlyTaskDates = IQWIA_WebApi.Helper.Helper.GetMonthlyData(clientRequest.StartDate, clientRequest.EndDate);

                //---- This commeneted code is used for call the data ina single call.----
                ////var monthlyTaskDates = new List<MonthlyRequest>();
                ////monthlyTaskDates.Add(new MonthlyRequest()
                ////{
                ////    StartDate = "2016-01-01T00:00:00.000Z",
                ////    EndDate = "2018-12-31T23:59:59.999Z"
                ////});
                //----This commeneted code is used for call the data ina single call. ----
                
                // Create list of Async task for different calls.
                List<Task<List<TweetDetail>>> tweetApiTaskList = new List<Task<List<TweetDetail>>>();

                // Add all the async calls into List of tasks
                foreach (var monthlyTask in monthlyTaskDates)
                {
                    tweetApiTaskList.Add(ProcessTweetApiAsync(client, monthlyTask));
                }

                // Craete the List of TweetDetail, which will be used for merging the task response into a single list.
                List<TweetDetail> allTweets = new List<TweetDetail>();
                foreach (var tweetApiTask in tweetApiTaskList)
                {
                    allTweets.AddRange(await tweetApiTask);
                }

                return allTweets;
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Call async for api calling
        /// </summary>
        /// <param name="client">Http Client</param>
        /// <param name="tweetRequest">request fpor running the report</param>
        /// <returns>return list of tweets</returns>
        async Task<List<TweetDetail>> ProcessTweetApiAsync(HttpClient client, MonthlyRequest tweetRequest)
        {
            // Number of records return from api 100 as per the requirement.            
            int numberOfRecordsFromApi = Convert.ToInt16(WebConfigurationManager.AppSettings["NumberOfRecordsFromApi"]);

            // Date fromat for UTC
            string dateFormat = Convert.ToString(WebConfigurationManager.AppSettings["DateFormat"]);

            List<TweetDetail> tweetList = new List<TweetDetail>();
            try
            {
                var isDataCompleted = false;
                var lastTweetOfCurrentRequest = new TweetDetail();

                while (!isDataCompleted)
                {
                    // APi call parameter
                    string urlParameters = "?startDate=" + tweetRequest.StartDate + "&endDate=" + tweetRequest.EndDate;

                    // List data response.
                    HttpResponseMessage response = await client.GetAsync(urlParameters);

                    if (response.IsSuccessStatusCode)
                    {
                        List<TweetDetail> tweetsResults = response.Content.ReadAsAsync<IEnumerable<TweetDetail>>().Result.ToList<TweetDetail>();

                        if (tweetsResults != null && tweetsResults.Count > 0)
                        {
                            // Append all the records to list
                            tweetList.AddRange(tweetsResults.Where(s => s.id != lastTweetOfCurrentRequest.id));

                            // If number of records are 100 it means there are more records.
                            // So set the start date as last tweet's timestamp and again call the api again till less than 100 records.
                            if (tweetsResults.Count == numberOfRecordsFromApi)
                            {
                                lastTweetOfCurrentRequest = tweetsResults.LastOrDefault();
                                tweetRequest.StartDate = DateTimeOffset.Parse(lastTweetOfCurrentRequest.stamp).UtcDateTime.ToString(dateFormat);
                            }
                            else // if records are not 100 it means all tweets so break the loop
                            {
                                isDataCompleted = true;
                            }
                        }
                        else
                        {
                            isDataCompleted = true;
                        }
                    }
                }

                return tweetList;
            }
            catch
            {
                throw;
            }
        }
    }
}