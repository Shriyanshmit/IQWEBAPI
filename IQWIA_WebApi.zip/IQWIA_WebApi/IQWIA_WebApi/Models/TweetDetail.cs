﻿
namespace IQWIA_WebApi.Models
{
    public class TweetDetail
    {
        public string id { get; set; }

        public string stamp { get; set; }

        public string text { get; set; }
    }
}