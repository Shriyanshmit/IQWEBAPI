﻿using IQWIA_WebApi.Models;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;

namespace IQWIA_WebApi.Controllers
{
    public class TweetsController : ApiController
    {
        /// <summary>
        /// Used for calling the api in asyn mode.
        /// </summary>
        /// <returns></returns>
        public async Task<List<TweetDetail>> GetTweets()
        {
            try
            {
                return await new TweetService().GetTweetsAsync(new ClientRequest()
                {
                    StartDate = new DateTime(2016, 01, 01),
                    EndDate = new DateTime(2018, 12, 31)
                });
            }
            catch (Exception ex)
            {
                // Log the exceptiona like log4net or custom logging etc.   

                var resp = new HttpResponseMessage(HttpStatusCode.NotFound)
                {
                    Content = new StringContent(string.Format("Create the error message for sowing to customer on UI")),
                    ReasonPhrase = ex.Message
                };
                throw new HttpResponseException(resp);
            }
        }
    }
}