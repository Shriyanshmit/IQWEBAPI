﻿using IQWIA_WebApi.Models;
using System;
using System.Collections.Generic;
using System.Web.Configuration;

namespace IQWIA_WebApi.Helper
{
    public class Helper
    {
        /// <summary>
        /// This method is used for create the list in one month gap.
        /// </summary>
        /// <param name="startDate">start date of the tweet</param>
        /// <param name="endDate">end date of the tweet</param>
        /// <returns>return list of months</returns>
        public static List<MonthlyRequest> GetMonthlyData(DateTime startDate, DateTime endDate)
        {
            List<MonthlyRequest> tweetRequest = new List<MonthlyRequest>();
            string dateFormat = Convert.ToString(WebConfigurationManager.AppSettings["DateFormat"]);
            int asyncTaskGap = Convert.ToInt16(WebConfigurationManager.AppSettings["AsyncTaskGap"]);
            
            while (startDate <= endDate)
            {
                var nextEndDate = startDate.AddMonths(1);

                if (nextEndDate > endDate)
                {
                    nextEndDate = endDate;
                }

                tweetRequest.Add(new MonthlyRequest()
                {
                    StartDate = new DateTime(startDate.Year, startDate.Month, startDate.Day, 00, 00, 00).ToString(dateFormat),
                    EndDate = new DateTime(nextEndDate.Year, nextEndDate.Month, nextEndDate.Day, 23, 59, 59, 999).ToString(dateFormat)
                });

                startDate = startDate.AddMonths(asyncTaskGap).AddDays(1);
            }

            return tweetRequest;
        }
    }
}