﻿app.service('CustomService', function ($http) {

    var urlGet = '';    
    this.getAll = function (apiRoute) {

        urlGet = apiRoute;
        return $http.get(urlGet);
    }

    this.getbyID = function (apiRoute, studentID) {

        urlGet = apiRoute + '/' + studentID;
        return $http.get(urlGet);
    }
});