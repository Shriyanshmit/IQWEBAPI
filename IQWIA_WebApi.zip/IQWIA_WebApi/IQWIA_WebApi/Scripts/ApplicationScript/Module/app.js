﻿var app;
(function () {
    'use strict';
    app = angular.module('tweetapp', []);
})();

app.filter('offset', function () {
    return function (input, start) {
        start = parseInt(start, 10);
        return input.slice(start);
    };
});