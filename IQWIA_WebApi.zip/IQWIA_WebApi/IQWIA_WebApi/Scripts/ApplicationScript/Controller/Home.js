﻿app.controller('HomeCtrl', ['$scope', 'CustomService',
    function ($scope, CustomService) {

        var baseUrl = '/api/Tweets/';
        $scope.StartDate = "2016-01-01T00:00:00.000Z";
        $scope.EndDate = "2018-12-31T23:59:59.999Z";
        $scope.ButtonText = "Load Tweets";

        $scope.Tweets = [];
        $scope.ViewTweets = [];
        $scope.TweetsJSONString = '';

        $scope.GetTweets = function () {
            var apiRoute = baseUrl + 'GetTweets/';
            var tweets = CustomService.getAll(apiRoute);
            $scope.ButtonText = "Please wait...";

            tweets.then(function (response) {
                $scope.ButtonText = "Load Tweets";
                $scope.Tweets = response.data;
                $scope.NoOfTweets = response.data.length;
                $scope.TweetsJSONString = JSON.stringify($scope.Tweets);
            },
            function (error) {
                $scope.ButtonText = "Load Tweets";
                alert("Error: " + error);
            });
        }

        $scope.ShowData = function () {
            $scope.ViewTweets = $scope.Tweets;
        }

    }]);