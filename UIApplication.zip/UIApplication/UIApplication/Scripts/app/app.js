﻿var app = angular.module('myApp', ['ui.router']);


app.service('CustomService', function () {
    this.UserDetails = { UserName: '' };
});


app.config(function ($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/home');

    $stateProvider
        .state('LoginPage', {
            url: '/home',
            templateUrl: 'LoginPage.html'
        })
        .state('HomePage', {
            url: '/home',
            templateUrl: 'HomePage.html'
        });
});

app.controller('loginController', function ($scope, $state, CustomService) {
    $scope.model = { username: '', password: '' };

    $scope.login = function () {       
        CustomService.UserDetails.UserName = $scope.model.username;
        $state.go('HomePage', {});
    }
});

app.controller('detailController', function ($scope, $state, $http, CustomService) {
    $scope.data = [];

    function loadData() {
        $scope.UserName = CustomService.UserDetails.UserName;
        $scope.data = [{ EID: 1, Name: 'A' }, { EID: 1, Name: 'B' }];
        //$http.get('jsonData.txt').then(function (res) {
        //    debugger;

        //});
    }

    $scope.DeleteData = function (item)
    {
        var index = $scope.data.indexOf(item);
        $scope.data.splice(index, 1);
        alert('Data Deleted successfully.');
    };

    $scope.EditData = function (item) {
        
    };

    loadData();
});
